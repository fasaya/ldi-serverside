<!DOCTYPE html>
<html>

<head>
    <title>Welcome</title>
</head>

<body>

    <p><?= $isi; ?></p>

</body>

</html>