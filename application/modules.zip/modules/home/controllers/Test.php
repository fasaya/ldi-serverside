<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Test extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
    }

    public function index()
    {
        // $hari_ini = new_date();
        // // $hari_ini = "2022-05-23 17:11:02";
        // $tahun_ini = date("Y", strtotime($hari_ini));
        // $bulan_ini = date("m", strtotime($hari_ini));

        // echo $bulan_ini . " /" . $tahun_ini;

        // echo 55000 % 10000;

    }
}
